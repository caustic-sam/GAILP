# Privacy Brief (Starter)

Cross-browser extension (Chrome/Edge/Firefox/Safari via conversion) that finds a site's privacy policy, summarizes it, and flags potential risks — **local-only by default**.

## Quick start

```bash
pnpm install
pnpm dev              # Chrome dev build
pnpm build:chrome     # Build ZIP-able bundle to ./dist
```

### Load in Chrome/Edge (dev)
1. `pnpm build:chrome`
2. Open `chrome://extensions` → **Developer mode** → **Load unpacked** → select `dist/`

### Firefox (dev)
- Build with `TARGET=firefox vite build` or `pnpm build:firefox`
- Load `about:debugging#/runtime/this-firefox` → **Load Temporary Add-on** → select any file in `dist/`

### Safari
1. Install Xcode.
2. Convert the web extension:
   ```bash
   xcrun safari-web-extension-converter ./dist --project-location ./safari
   ```
3. Open the Xcode project, enable Web Extension capability, sign, and run.

## What’s included
- MV3 manifest with **DNR** rules (GPC/DNT) and content/background scripts.
- TypeScript sources for parser, summarizer (extractive template), heuristics/scoring.
- Minimal popup UI with score, sections, flags.
- Options page with GPC/DNT toggle and cache limit.
- `rules/gpc.json` (enabled by default) — toggle via popup/opts.

## Notes
- Background parser uses `DOMParser` when available; falls back to HTML-to-text when not.
- No cloud calls; only fetches the policy page HTML.
- This is a scaffold aligned with your playbook — safe defaults and room to expand (local LLM, richer NLP, tests).

## Scripts
- `pnpm dev` — run Vite in watch mode for Chrome
- `pnpm build` — build for Chrome (default)
- `pnpm build:chrome|edge|firefox` — target specific browser
- `pnpm zip` — zip the `dist/` folder

---

Generated: 2025-11-06T02:10:28.261251Z
