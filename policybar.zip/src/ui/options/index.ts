import browser from 'webextension-polyfill'

async function load() {
  const st = (await browser.storage.local.get('settings'))['settings'] || { gpcEnabled:false, cacheLimit:100 }
  ;(document.getElementById('gpc') as HTMLInputElement).checked = !!st.gpcEnabled
  ;(document.getElementById('cacheLimit') as HTMLInputElement).value = String(st.cacheLimit || 100)
}
async function save() {
  const gpcEnabled = (document.getElementById('gpc') as HTMLInputElement).checked
  const cacheLimit = parseInt((document.getElementById('cacheLimit') as HTMLInputElement).value, 10) || 100
  const settings = { gpcEnabled, cacheLimit }
  await browser.storage.local.set({ settings })
  await browser.runtime.sendMessage({ type: 'SET_GPC', enabled: gpcEnabled })
  alert('Saved.')
}

document.getElementById('save')!.addEventListener('click', save)
load().catch(()=>{})