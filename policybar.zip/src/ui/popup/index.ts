import browser from 'webextension-polyfill'

async function main() {
  const [tab] = await browser.tabs.query({active:true,currentWindow:true})
  const domain = new URL(tab.url!).hostname
  const data = (await browser.storage.local.get(domain))[domain]

  const elScore = document.getElementById('score')!
  const elSections = document.getElementById('sections')!
  const elFlags = document.getElementById('flags')!
  const elGpc = document.getElementById('gpc') as HTMLInputElement

  // Initialize GPC checkbox from settings
  const st = (await browser.storage.local.get('settings'))['settings'] || {}
  elGpc.checked = !!st.gpcEnabled
  elGpc.addEventListener('change', async () => {
    const settings = { ...(await browser.storage.local.get('settings'))['settings'], gpcEnabled: elGpc.checked }
    await browser.storage.local.set({ settings })
    await browser.runtime.sendMessage({ type: 'SET_GPC', enabled: elGpc.checked })
  })

  if (!data) { elScore.textContent = 'No analysis yet.'; return }

  elScore.textContent = `Risk score: ${data.score}`
  ;(data.sections||[]).forEach((s:any) => {
    const d = document.createElement('div')
    d.innerHTML = `<strong>${s.title}</strong><ul>${(s.bullets||[]).map((b:string)=>`<li>${b}</li>`).join('')}</ul>`
    elSections.appendChild(d)
  })
  ;(data.flags||[]).forEach((f:any) => {
    const div = document.createElement('div')
    div.className = 'flag ' + (f.severity==='high'?'H':f.severity==='med'?'M':'L')
    div.textContent = `${f.id}: ${f.evidence || ''}`
    elFlags.appendChild(div)
  })
}
main().catch(()=>{})