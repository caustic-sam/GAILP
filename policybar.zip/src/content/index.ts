import browser from 'webextension-polyfill'

function getAnchor(el: Element): string | undefined {
  const id = (el as HTMLElement).id
  if (id) return `#${id}`
  return undefined
}

function findPrivacyCandidates(): { href: string; anchor?: string }[] {
  const anchors = Array.from(document.querySelectorAll<HTMLAnchorElement>('a[href]'))
  const candidates = anchors.filter(a => {
    const t = (a.textContent || '').toLowerCase()
    const h = a.href.toLowerCase()
    return /privacy|legal\/?privacy|privacy-policy/.test(t) || /privacy/.test(h)
  })
  return candidates.map(a => ({ href: a.href, anchor: getAnchor(a) }))
}

// notify background when DOM ready
queueMicrotask(() => {
  const links = findPrivacyCandidates()
  browser.runtime.sendMessage({ type: 'CANDIDATE_LINKS', links }).catch(() => {})
})