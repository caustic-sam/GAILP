export function parsePolicyHtml(url: string, html: string) {
  // Attempt to parse in the background context. If DOMParser is unavailable, fall back to plain text.
  let text = ''
  let outline: { level: number; text: string; anchor?: string }[] = []
  try {
    // @ts-ignore
    const parser = new DOMParser()
    const doc = parser.parseFromString(html, 'text/html')
    doc.querySelectorAll('nav, header, footer, script, style, noscript').forEach(n => n.remove())
    const main = doc.querySelector('main, article') || largestBlock(doc.body)
    text = serialize(main)
    outline = headings(main)
  } catch {
    text = stripHtml(html)
    outline = []
  }
  return { url, text, outline }
}

function largestBlock(root: Element): Element {
  let best: Element = root, bestLen = 0
  root.querySelectorAll('div, section').forEach(el => {
    const len = (el.textContent || '').length
    if (len > bestLen) { best = el; bestLen = len }
  })
  return best
}

function serialize(el: Element): string {
  const parts: string[] = []
  el.querySelectorAll('h1, h2, h3, h4, p, li').forEach(node => {
    const tag = node.tagName.toLowerCase()
    const t = node.textContent?.trim()
    if (!t) return
    if (tag.startsWith('h')) parts.push('#'.repeat(Number(tag[1])) + ' ' + t)
    else if (tag === 'li') parts.push('- ' + t)
    else parts.push(t)
  })
  return parts.join('\n')
}

function headings(el: Element) {
  return Array.from(el.querySelectorAll('h1, h2, h3, h4')).map(h => ({
    level: Number(h.tagName[1]),
    text: h.textContent?.trim() || '',
    anchor: h.id ? `#${h.id}` : undefined
  }))
}

function stripHtml(html: string): string {
  return html.replace(/<script[\s\S]*?<\/script>/gi,'')
             .replace(/<style[\s\S]*?<\/style>/gi,'')
             .replace(/<[^>]+>/g,' ')
             .replace(/\s+/g,' ').trim()
}