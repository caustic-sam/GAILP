import type { Summary, Section } from '../types/summary'

export function summarizeExtractive(policy: { url: string; text: string; outline: any[] }): Summary {
  const sections = splitByHeadings(policy.text)

  const sec = (title: string, pattern: RegExp) => pickSection(title, sections, pattern)

  const assembled: Section[] = [
    sec('Data Collected', /collect|information\s+we\s+collect|data\s+we\s+collect/i),
    sec('Purposes/Use', /use|purpose/i),
    sec('Sharing/Partners', /share|third[- ]part|sell|advertis/i),
    sec('Your Rights', /right|access|delete|opt[- ]out|rectif|portab|object|restrict/i),
    sec('Retention', /retain|storage period|delete after|retention/i),
    sec('International Transfers', /transfer|EEA|SCC|adequacy|international transfer/i)
  ].filter(Boolean) as Section[]

  const summary: Summary = {
    url: policy.url,
    fetchedAt: new Date().toISOString(),
    sections: assembled,
    flags: [],
    rights: {},
    transfers: {},
    retention: {},
    contacts: {},
    score: 0
  }
  return summary
}

function splitByHeadings(text: string): string[] {
  // Rough heading split by markdown-ish headings produced by parser
  return text.split(/\n(?=#)/g)
}

function pickSection(title: string, chunks: string[], pattern: RegExp): Section | null {
  const match = chunks.find(c => pattern.test(c))
  if (!match) return null
  const lines = match.split(/\n/).slice(0, 12)
  const bullets = lines.filter(l => !l.startsWith('#')).slice(0, 6).slice(0,3) // up to 3 bullets
  return { title, bullets, quoteRefs: [] }
}