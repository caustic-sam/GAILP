import type { Summary } from '../types/summary'

const RULES = [
  { id: 'precise_location',  label: 'Collects precise location',  severity: 'high',  re: /precise location|gps|latitude|longitude/i, w: 18 },
  { id: 'biometrics',        label: 'Collects biometrics',        severity: 'high',  re: /biometric|faceprint|fingerprint|voiceprint/i, w: 20 },
  { id: 'sale_share',        label: 'Sells or shares data',       severity: 'high',  re: /sell|sale of personal.*data|share.*(targeted|cross[- ]context)/i, w: 22 },
  { id: 'ad_tracking',       label: 'Cross-site ad tracking',     severity: 'med',   re: /third[- ]party cookie|pixel|sdk|track across sites/i, w: 10 },
  { id: 'retention_indef',   label: 'Indefinite/unclear retention',severity: 'med',  re: /retain.*indefinite|no (set|specific) retention|as long as necessary/i, w: 8 },
  { id: 'children',          label: 'Children data involved',     severity: 'high',  re: /child(ren)?|under (13|16)|coppa/i, w: 12 },
  { id: 'law_enforcement',   label: 'Broad LE disclosure',        severity: 'med',   re: /law enforcement|authorit(y|ies)|government request/i, w: 6 },
  { id: 'legitimate_interest',label:'Broad legitimate interests', severity: 'low',   re: /legitimate interest/i, w: 4 },
  { id: 'intl_transfers',    label: 'International transfers',    severity: 'low',   re: /EEA|SCC|adequacy|international transfer/i, w: 4 },
  { id: 'gpc_not_honored',   label: 'GPC not honored',            severity: 'med',   re: /global privacy control.*(not|no)/i, w: 10 }
] as const

export function evaluateHeuristics(summary: Summary): Summary {
  const text = (summary.sections || []).map(s => (s.bullets||[]).join('\n')).join('\n')
  const flags: { id: string; severity: 'low'|'med'|'high'; evidence?: string }[] = []
  let score = 50
  for (const r of RULES) {
    const m = text.match(r.re)
    if (m) {
      const idx = m.index || 0
      const evidence = text.slice(Math.max(0, idx - 80), idx + 120).replace(/\n/g, ' ')
      flags.push({ id: r.id, severity: r.severity as any, evidence })
      score += r.w
    }
  }
  score = Math.max(0, Math.min(100, score))
  return { ...summary, flags, score }
}