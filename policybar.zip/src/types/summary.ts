export interface QuoteRef { text: string; anchor?: string }
export interface Section { title: string; bullets: string[]; quoteRefs?: QuoteRef[] }
export interface Rights {
  access?: boolean; delete?: boolean; optOutSale?: boolean; portability?: boolean;
  rectify?: boolean; object?: boolean; restrict?: boolean; nonDiscrimination?: boolean;
}
export interface Transfers { international?: boolean; mechanism?: string[] }
export interface Retention { stated?: boolean; period?: string | null }
export interface Contacts { dpoEmail?: string; formUrl?: string }
export interface Flag { id: string; severity: 'low'|'med'|'high'; evidence?: string; anchor?: string }

export interface Summary {
  url: string; fetchedAt: string;
  sections: Section[]; flags: Flag[];
  rights: Rights; transfers: Transfers; retention: Retention; contacts: Contacts;
  score: number;
}