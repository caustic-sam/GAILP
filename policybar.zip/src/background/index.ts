import browser from 'webextension-polyfill'
import { parsePolicyHtml } from '../lib/parser'
import { summarizeExtractive } from '../lib/summarizer'
import { evaluateHeuristics } from '../lib/heuristics'

// Small in-memory cache for quick hits
const mem = new Map<string, any>()

// Handle messages from content/options
browser.runtime.onMessage.addListener(async (msg, sender) => {
  if (msg?.type === 'CANDIDATE_LINKS') {
    const tabUrl = sender?.tab?.url || ''
    if (!tabUrl) return
    const domain = safeHostname(tabUrl)
    if (!domain) return
    if (mem.has(domain)) {
      const result = mem.get(domain)
      await setBadge(sender.tab!.id!, result.score)
      return
    }
    const urls = candidateUrls(domain, (msg.links || []).map((l:any)=>l.href))
    const result = await analyzeFirstFound(urls)
    if (result) {
      cacheResult(domain, result)
      await setBadge(sender.tab!.id!, result.score)
    } else {
      await browser.action.setBadgeText({ text: '–', tabId: sender.tab!.id! })
    }
  }
  if (msg?.type === 'SET_GPC') {
    await toggleGpc(Boolean(msg.enabled))
  }
})

function safeHostname(url: string): string | null {
  try { return new URL(url).hostname } catch { return null }
}

function candidateUrls(domain: string, found: string[]): string[] {
  const canonical = (u:string) => u.replace(/[#?].*$/, '')
  const list = Array.from(new Set([
    ...found,
    `https://${domain}/privacy`,
    `https://${domain}/privacy-policy`,
    `https://${domain}/legal/privacy`,
  ].map(canonical)))
  return list
}

async function analyzeFirstFound(urls: string[]) {
  for (const url of urls) {
    try {
      const resp = await fetch(url, { credentials: 'omit', cache: 'no-cache' })
      const ctype = resp.headers.get('content-type') || ''
      if (!resp.ok || !ctype.includes('text/html')) continue
      const html = await resp.text()
      const policy = parsePolicyHtml(url, html)
      const summary = summarizeExtractive(policy)
      const result = evaluateHeuristics(summary)
      return result
    } catch (e) {
      // try next
    }
  }
  return null
}

function cacheResult(domain: string, result: any) {
  mem.set(domain, result)
  browser.storage.local.set({ [domain]: result }).catch(()=>{})
}

async function setBadge(tabId: number, score: number) {
  await browser.action.setBadgeText({ text: String(Math.max(0, Math.min(99, Math.round(score)))) , tabId })
  if (score >= 80) await browser.action.setBadgeBackgroundColor?.({ color: '#b00020', tabId })
  else if (score >= 60) await browser.action.setBadgeBackgroundColor?.({ color: '#e67e22', tabId })
  else await browser.action.setBadgeBackgroundColor?.({ color: '#2e7d32', tabId })
}

// Enable/disable DNR ruleset for GPC/DNT (Chrome/Edge). Firefox/Safari will ignore.
async function toggleGpc(enabled: boolean) {
  // @ts-ignore
  const dnr = chrome && chrome.declarativeNetRequest
  if (dnr && dnr.updateEnabledRulesets) {
    const toEnable = enabled ? ['gpc'] : []
    const toDisable = enabled ? [] : ['gpc']
    // @ts-ignore
    await chrome.declarativeNetRequest.updateEnabledRulesets({ enableRulesetIds: toEnable, disableRulesetIds: toDisable })
  }
}